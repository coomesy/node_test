
const _ = require('lodash')
const globalSanitation = require('../global/global-utilities')


class TransactionsDataAccess {
    constructor(dataAccessor) {
        this.dataAccessor = dataAccessor
        this.collection = 'transactions'
        this.properties = ['energyRate', 'energyValue', 'coinsInc', 'coinsDec', 'energyInc', 'energyDec',  'transactionId' ,'timestamp', 'status'] 
    }

    findAllTransactions() {
        return this.dataAccessor.findAll(this.collection) 
    }

    findTransaction(id) {       
        return this.dataAccessor.findbyId(this.collection, id)
    }

    addMultipleTransactions(transactions){
        let newTransactions =  transactions.map(transaction => globalSanitation(transaction, this.properties)) //MOVE TO GLOBAL 
        return this.dataAccessor.addMultipleItems(this.collection, newTransactions)
    }

    addSingleTransaction(newTransaction){       
        let transaction = globalSanitation(newTransaction, this.properties)    
        return this.dataAccessor.addItem(this.collection, transaction)        
    }

    deleteAllTransactions(){
        return this.dataAccessor.deleteAll(this.collection)
    }

    deleteTranById(id){
        return  this.dataAccessor.deleteById(this.collection, id)
    }

    updateTransaction(transaction, id){       
      let updateTransaction = globalSanitation(transaction, this.properties)      
      return this.dataAccessor.update(this.collection, id, updateTransaction)
    }
}


module.exports = TransactionsDataAccess
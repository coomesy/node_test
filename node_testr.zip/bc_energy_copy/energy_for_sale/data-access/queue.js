var mongodb = require('mongodb').MongoClient;
var mongoDbQueue = require('mongodb-queue');

const config = require('./config.js')
let url = process.env.MONGO_URL || 'mongodb://admin:change01@172.21.0.4:27017/EnergyApp?authSource=admin'

//TODO replace all Que with a variable that can be passed to the route
// For example /quote/<energyForSale_ID>
//then Que = energyForSale_ID

let enqueue = (doc, queueID) =>{
    return new Promise((resolve, reject) =>{
        mongodb.connect(url, function(err, db){
            if(err){
                reject(err);
            }else{
                let queue = mongoDbQueue(db, queueID);
                console.log('enqueing')
                console.log(doc)
                queue.add(doc, function(err, id){
                    if(err){
                        reject(err);
                    }else{
                        resolve(id);
                    }
                })
            }
        })
    })
}


let dequeue = (queueID) =>{
    return new Promise((resolve, reject) =>{
        mongodb.connect(url, function(err, db){
            if(err){
                return reject(err);
            }else{
                let queue = mongoDbQueue(db, queueID);
                queue.get(function(err, doc){
                    if(err || typeof doc === 'undefined'){
                        return reject(err)
                    }
                    let item = doc;
                    console.log('checking doc ')
                    console.log(doc)
                    queue.ack(doc.ack, function(err, id){
                        console.log('removed '+id);
                        console.log(item)
                    });
                    resolve(item);
                })
            }
        })
    })
}

let isEmpty = ( queueID) =>{
    return new Promise((resolve, reject) =>{
        mongodb.connect(url, function(err,db ){
            if(err){
                return reject(err);
            }else{
                let queue = mongoDbQueue(db, queueID);
                queue.size(function(err, count){
                    if(err){
                        return reject(err);
                    }
                    console.log('This queue has %d current messages', count)
                    if(count <= 0){
                        resolve(true)
                    }else{
                        resolve(false)
                    }
                })
            }
        })
    })
}

let wipeClean = ( queueID) =>{
    return new Promise((resolve, reject) =>{
        mongodb.connect(url, function(err, db){
            if(err){
                return reject(err)
            }else{
                let queue = mongoDbQueue(db, queueID);
                queue.clean(function(err){
                    console.log('The processed messages have been deleted from the queue')
                    if(err){
                        reject(err)
                    }else{
                        resolve(true)
                    }
                })
            }
        })
    })
}

module.exports = {wipeClean, isEmpty, dequeue, enqueue}
const express = require('express')
const router = express.Router()
const url = require('../config/config.js')
const {ObjectID} = require('mongodb')
const MongoDataAccess  = require( '../mongo-access/data-access')
const EnergyDataAccess = require('../data-access/energy-data-access')
const energyDataAccess = new EnergyDataAccess(new MongoDataAccess(url.url))  // should be set up in a different file? AND CHANGE URL NAME

let appRoot = require('app-root-path')
let logger = require(`${appRoot}/config/winston`).getLogger('routes/energy-routes')

router.get('/',(req, res) => {
    energyDataAccess.findAllEnergy()
    .then((result) => res.status(200).send(result)
      ,(error) => res.status(500).send(error))
})

router.get('/:id',(req, res) => {
  const id = req.params.id

  if(!ObjectID.isValid(id))  //Currently using mongo id's - Change if not longer using mongo id's
    return res.status(400).send('Invalid Id')

  energyDataAccess.findEnergy(id)
    .then((result) => result.length ==0 ? res.status(404).send('Item not found') : res.status(200).send(result)   
    ,(error) => res.status(500).send(error))
})

router.post('/', (req, res) => {
  const newEnergy = req.body

    if(newEnergy.length > 0){
      //console.log('Adding MORE THAN 1 Energy Item', JSON.stringify(newEnergy, undefined, 2))
      energyDataAccess.addMultipleEnergyItems(newEnergy)
        .then((result) => res.status(201).send(result.ops)
              ,(error) => res.status(500).send(error))
      }
      else{    
        //console.log('Adding 1 Energy Item', JSON.stringify(newEnergy, undefined, 2))
        energyDataAccess.addEnergyItem(newEnergy)
          .then((result) => res.status(201).send(result.ops)
            , (error) => res.status(500).send(error))
      }
})

router.put('/:id',  (req, res) => {
  const id = req.params.id

  if(!ObjectID.isValid(id))  //Currently using mongo id's - Change if not longer using mongo id's
      return res.status(400).send('Invalid Id')

  energyDataAccess.updateEnergyItem(req.body, id)
  .then((result) => result.value==null ?  res.status(404).send('ID not found') : res.status(204).send()           
        ,(error) => res.status(500).send(error))
})

router.delete('/', (req, res) => {
  energyDataAccess.deleteAllEnergy()
  .then((result) => res.status(200).send('Deleted All Energy')
    , (error) => res.status(500).send(error))
})

router.delete('/:id', (req, res) => {
  const id = req.params.id

  if(!ObjectID.isValid(id))  //Currently using mongo id's - Change if not longer using mongo id's
      return res.status(400).send('Invalid Id')

  energyDataAccess.deleteEnergyById(id)
    .then((result) => result.value==null ?  res.status(404).send('ID not found') : res.status(204).send() 
         ,(error) => res.status(500).send(error))
  })

module.exports = router
const express = require('express')
const router = express.Router()
const {ObjectID} = require('mongodb')
const url = require('../config/config.js')

const MongoDataAccess  = require( '../mongo-access/data-access')
const TransactionsDataAccess = require('../data-access/transactions-data-access')
const transactionsDataAccessor = new TransactionsDataAccess(new MongoDataAccess(url.url))  //this should be set up in a different file AND DIFF NAME! 

router.get('/', (req, res) => {
   transactionsDataAccessor.findAllTransactions()
    .then((result) => res.status(200).send(result)
        ,(error) => res.status(500).send(error))   
})

router.post('/', (req, res) => {
    const transactions = req.body
    if(req.body.length > 0){    
        transactionsDataAccessor.addMultipleTransactions(transactions)
        .then((result) =>res.status(201).send(result.ops)
        ,(error) => res.status(500).send(error))
    } else{       
        transactionsDataAccessor.addSingleTransaction(req.body) 
         .then((result) =>  res.status(201).send(result.ops)
         ,(error) => res.status(500).send(error))
    }
})
  
router.get('/:id',  (req, res) => {        
    const id = req.params.id

    if(!ObjectID.isValid(id)) 
        return res.status(400).send('Invalid ID')  

    transactionsDataAccessor.findTransaction(id)
    .then((result) => result.length ==0 ? res.status(404).send('Item not found') : res.status(200).send(result)                       
    ,(error) => res.status(500).send(error))   
})

router.delete('/', (req, res) => {
    transactionsDataAccessor.deleteAllTransactions()
    .then((result) => res.status(200).send('Deleted All Transactions')
      , (error) => res.status(500).send(error))
  })

router.put('/:id', (req, res) => { 
    const id = req.params.id

    if (!ObjectID.isValid(id)) 
         return res.status(400).send('Invalid ID')

    transactionsDataAccessor.updateTransaction(req.body, id)
        .then((result) => result.value==null ?  res.status(404).send('ID not found') : res.status(204).send()           
             ,(error) => res.status(500).send(error)) 
}) 

router.delete('/:id', (req, res) => { 
    const id = req.params.id

    if (!ObjectID.isValid(id))  //Checks if Id exists 
        return res.status(404).send()

    transactionsDataAccessor.deleteTranById(id)
    .then((result) =>  result.value==null ?  res.status(404).send('ID not found') : res.status(204).send()    
        , (error) => res.status(500).send(error))   
})
  
module.exports = router
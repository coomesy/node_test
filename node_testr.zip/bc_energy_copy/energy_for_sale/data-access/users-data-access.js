
const _ = require('lodash')
const globalSanitation = require('../global/global-utilities')

class usersDataAccess {
    constructor(dataAccessor) {
        this.dataAccessor = dataAccessor
        this.collection = 'users'
        this.properties = ['username', 'password', 'energyID', 'cashID', 'coinID', 'address', 'state', 'transactions', 'alias', 'resident_type', 'kWhUsed'] 
    }

    findAllUsers(){
        return this.dataAccessor.findAll(this.collection)
    }

    addMultipleUsers(users){
        let newUsers =  users.map(user => globalSanitation(user, this.properties)) //MOVE TO GLOBAL 
        return this.dataAccessor.addMultipleItems(this.collection, newUsers)
    }
    
    addUser(user){
       const newUser= globalSanitation(user, this.properties)
       return this.dataAccessor.addItem(this.collection, newUser)
    }

    findUserById(id){
        return this.dataAccessor.findbyId(this.collection, id)
    }
    
    deleteUserById(id){
        return this.dataAccessor.deleteById(this.collection, id)
    }
    
    deleteAllUsers(){
        return this.dataAccessor.deleteAll(this.collection)
    }

    updateUser(id, update){
        let newUpdata = globalSanitation(update, this.properties)
        return this.dataAccessor.update(this.collection, id, newUpdata)        
    }
}


module.exports = usersDataAccess
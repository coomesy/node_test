require('dotenv').load()

if(process.env.NODE_ENV == 'local')
    url = process.env.MONGO_URL_LOCAL
else{
    url= process.env.MONGO_URL
}

module.exports = {
    url
}

const {MongoClient , ObjectID} = require('mongodb')

let url = process.env.MONGODB_URI || 'mongodb://localhost:27017/EnergyApp'


let addMultipleItems = (collectionName, docs) => {
  return new Promise((resolve, reject) => {
    MongoClient.connect(url, (err,db) => {
      if(err){
        reject(err)
      }
      else{
        db.collection(collectionName).insertMany(docs)
        .then((docs) => resolve(docs), 
        (err) => reject(err))        
      }
    })
  })
}

let deleteByTransactionId = (collectionName, transactionId) => {
  return new Promise((resolve, reject) => {          
      MongoClient.connect(url, (err, db) => {
      if(err){
        reject(err)
      }
      else{
        db.collection(collectionName).findOneAndDelete({_id: new ObjectID(transactionId)})
        .then(
        (doc) => resolve(doc),             
        (err) => reject(err))                  
      }})
    })
}

let addItem = (collectionName, transaction) => {
  return new Promise((resolve, reject) => {
   MongoClient.connect(url, (err, db) => {
      if(err){
         reject(err)
      }else{
       db.collection(collectionName).insertOne(transaction, (err, doc) => {
          if(err){
              reject(err)
          }else{
          console.log(JSON.stringify(doc.ops, undefined, 2))
          resolve(doc.ops)
       }
     })
  }})
})}    

let findAll = (collectionName) => {
    return new Promise((resolve, reject) => {          
        MongoClient.connect(url, (err, db) => {
          if(err){
            reject(err)
          }else{
            db.collection(collectionName).find().toArray().then(
                (docs) => resolve(docs), 
                (err) => reject(err))
          }
     })
  })
}
// /* DELETE BY WHAT */ 
// let updateTransaction = (collectionName, transactionId, body) => {
//   return new Promise((resolve, reject) => {
//     MongoClient.connect(url, (err, db) => {
//       if(err){
//         reject(err)
//       }
//       else{
//         db.collection(collectionName).findOneAndUpdate({_id: new ObjectID(transactionId)}, 
//         {
//           $set: {
//             energyRate: body.energyRate,
//               energyValue: body.energyValue,
//               coinsInc: body.coinsInc,
//               coinsDec: body.coinsDec,
//               energyInc: body.energyInc,
//               energyDec:body.energyDec,
//               transactionId: body.transactionId,
//               timestamp: body.timestamp,
//               status: body.status
//           }
//         }, 
//         {
//           returnOriginal:false          
//         }
//         ).then(
//           (doc) => resolve(doc),             
//           (err) => reject(err))           
//       }
//     })
//   })
// }

// let findTransactionbyId = (collectionName, transactionID) => {
//   return new Promise((resolve , reject) => {
//     MongoClient.connect(url, (err, db) => {
//       if(err){
//         reject(err)
//       }else{
//         db.collection(collectionName).find({_id: new ObjectID(transactionID)}).toArray().then(
//             (doc) => resolve(doc), 
//             (err) => reject(err))
//       }
//    })
//  }) 
// }




module.exports ={findAll, addItem, deleteByTransactionId, addMultipleItems}
var express = require('express')
var router = express.Router()
const _ = require('lodash')
const {findAll, addItem, addMultipleItems, deleteByTransactionId} = require('../data-access/generic-collection')
const collectionName = 'generic'


router.post('/', function (req, res) {
  const users = req.body
    if(req.body.length > 0){    
        addMultipleItems(collectionName, users) 
        .then((result) =>
        {res.send(result)
            console.log(result)
        },
        (error) => {res.status(500).send(error)
            console.log(error)
        })
      }else{

     console.log(req.body)
  
      addItem(collectionName,req.body).then((result) => {
        res.send(result)
        }, (error) => {
        res.status(500).send(error)
      })
    }
})

router.get('/', function (req, res) {
//    res.send('sjdksdj')
    findAll(collectionName).then((result) => {
        res.send(result)
        }, (error) => {
        res.status(500).send(error)
      })
  })


router.delete('/:id', function(req, res) {
    const username = req.params.id
    deleteByTransactionId(collectionName, username).then((result) => {
      res.send(result)
      }, (error) => {
      res.status(500).send(error)
    })

  })



module.exports = router
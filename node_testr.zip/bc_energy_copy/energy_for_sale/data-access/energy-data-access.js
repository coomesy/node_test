const _ = require('lodash')
const globalSanitation = require('../global/global-utilities')

let appRoot = require('app-root-path')
let logger = require(`${appRoot}/config/winston`).getLogger('data-access/energy-data-access')


class energyDataAccess{
    constructor(energyAccesor){
        this.dataAccessor = energyAccesor
        this.collection = 'energy'
        this.properties = ['username', 'alias', 'pricePerkWh', 'kWh']
    }

    findAllEnergy(){
        console.log('2121212')
        logger.info('CALLING GET ALL IN ENERGY!!!')
        logger.info('infoooo!!!')

        //logger.info('CALLING GET ALL IN ENERGY!!!')
        return this.dataAccessor.findAll(this.collection)
    }    

    findEnergy(id){
        return this.dataAccessor.findbyId(this.collection, id)
    }

    addMultipleEnergyItems(energyItems){    
        let EnergyItems =  energyItems.map(energy => globalSanitation(energy, this.properties))

        logger.info('RETURNED FROM GLOBAL SANITATION:', JSON.stringify(EnergyItems, undefined, 2))

        return this.dataAccessor.addMultipleItems(this.collection, EnergyItems)
    }

    addEnergyItem(energy) {
        let newEnergy = globalSanitation(energy, this.properties)
        //console.log('RETURNED FROM GLOBAL SANITATION:', JSON.stringify(newEnergy, undefined, 2))
        return this.dataAccessor.addItem(this.collection, newEnergy)
    }

    updateEnergyItem(energyUpdate, id){
        let updateEnergyItem = globalSanitation(energyUpdate, this.properties)
        console.log('RETURNED FROM GLOBAL SANITATION:', JSON.stringify(updateEnergyItem, undefined, 2))
        return this.dataAccessor.update(this.collection, id, updateEnergyItem)
    }

    deleteEnergyById(id) {
        return this.dataAccessor.deleteById(this.collection, id)
    }

    deleteAllEnergy(){
        return this.dataAccessor.deleteAll(this.collection)
    }

}


module.exports = energyDataAccess
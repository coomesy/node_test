
const _ = require('lodash')

let globalSanitation = (obj, properties) =>  {
    newObject = _.pick(obj, [...properties])
    //console.log('Sanitized In Global Sanitazion:', JSON.stringify(newObject, undefined, 2))
    return newObject
}

module.exports = globalSanitation
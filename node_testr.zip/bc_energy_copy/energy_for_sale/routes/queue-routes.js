var express = require('express');
var router = express.Router();
const Que = require('../data-access/q')

// Creates new EnergyForSale Listing Que
router.post('/', function(req, res){
  let doc = req.body;
  let q = new Que({name: req.body.id})
  q.createQueue(doc, (id) => {
    res.send(JSON.stringify(id))
  })
});

router.post('/addBuyer', function(req, res) {
  let q = new Que({name: req.body.id})
  let date = new Date()
    req.body.timestamp = date.getTime().toString()
    q.addToQue(req.body, (doc) => {
      res.send(doc)
    })
})

router.post('/dequeue', function(req, res) {
  let q = new Que({name: req.body.id})
    q.dequeue(req.body, (doc) =>{
      console.log("Dequeue sending back "+doc)
      if(doc != null){
        res.send(doc)
      }else{
        res.status(400).send(doc)
      }
    })
})

router.post('/isEmpty', function(req, res) {
    let q = new Que({name: req.body.id})
    q.isEmpty((doc) =>{
      res.send(doc)
    })
})

router.post('/clean', function(req, res) {
    let q = new Que({name: req.body.id})
    q.wipeClean((doc) =>{
        res.send(doc)
    })
})

// Reads the desired EnergyForSale Que
router.post('/read', function(req, res){
  let q = new Que({name: 'query'})
  console.log(req.body.id)
  q.getQueue(req.body.id, (err, queue) => {
    if(err) {
      res.send(err)
    } else {
      res.send(queue)
    }
  })
})

// Deletes Listing once Sale is confirmed
router.delete('/', function(req, res){

})

module.exports = router

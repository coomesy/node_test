const express = require('express')
const router = express.Router()
const {ObjectID} = require('mongodb')
const url = require('../config/config.js')
const MongoDataAccess  = require( '../mongo-access/data-access')

const UsersDataAccess = require('../data-access/users-data-access')
const usersDataAccess= new UsersDataAccess(new MongoDataAccess(url.url)) //this should be set up in a different file AND CHANGE NAME

router.get('/',  (req, res) => {
    usersDataAccess.findAllUsers()
    .then((result) => {
        res.send(result)
    }, (error) => {
        res.status(500).send(error)
    })
  })

  router.get('/:id',  (req, res) => {        
    const userId = req.params.id

    if (!ObjectID.isValid(userId)) 
        return res.status(404).send()

    usersDataAccess.findUserById(userId)
        .then((result) => {
            res.send(result)
        }, (error) => {
            res.status(500).send(error)
        })   
})

router.post('/', (req, res) => {
    const newUsers = req.body

    if(req.body.length > 0){    
        //console.log('MORE THAN 1', JSON.stringify(newUsers, undefined, 2))
        usersDataAccess.addMultipleUsers(newUsers)
        .then((result) =>{
            res.send(result)
        }, (error) => {
            res.status(500).send(error)
        })
      }else{     
        //console.log('LESS THAN 1', JSON.stringify(newUsers, undefined, 2))
        usersDataAccess.addUser(newUsers) 
         .then((result) => {
             res.send(result)
            },(error) => {
            res.status(500).send(error)
        })
    }
})

router.put('/:id', (req, res) => {
    const userId = req.params.id

    if (!ObjectID.isValid(userId))  //Using mongo id's change if no longer using them 
        return res.status(404).send()

    usersDataAccess.updateUser(userId, req.body)
    .then((result) => {
        res.send(result)
    }, (error) => {
        res.status(500).send(error)
    }) 
}) 

router.delete('/:id', (req, res) => {
    const userId = req.params.id

    if (!ObjectID.isValid(userId)) 
        return res.status(404).send()

    usersDataAccess.deleteUserById(userId)
    .then((result) => {
        res.send(result)
    }, (error) => {
        res.status(500).send(error)
    })   
})


router.delete('/', (req, res) => { 

    usersDataAccess.deleteAllUsers()
    .then((result) => {
      res.send(result)
      }, (error) => {
      res.status(500).send(error)
    })
  })


module.exports = router
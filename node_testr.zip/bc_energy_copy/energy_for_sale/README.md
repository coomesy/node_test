## Development Workflow Changes

### Items Added
    * docker
    * docker-compose
    * pm2

### Running Application
```
cd energy_for_sale/env/composer-files
docker-compose -f node-mongo.yml build
docker-compose -f node.mongo.yml up
```

This will run the energy_for_sale API , mongo, and mongo-express (UI for MongoDB) in seperate docker containers.
The compose file also proxies the api (localhost:3050/api/) and mongo-express (localhost:3050/). 


PM2 handles running the node process and logging issues, logging is enhanced with Winston.

## Queue API Documentation

POST --> ```/queue```
Creates a queue for an EnergyForSale Listing

Example:
```
{
	"id" : "01-QUE"
}
```
POST --> ```/queue/addBuyer```
Adds a buyer to the specified Queue
The server adds a timestamp for client reference

Example:
```
{
	"id": "01-QUE",
	"buyer_id" : "",
	"seller_id" : ""
    ... etc
}
```

POST --> ```/queue/read```
Reads the desired EnergyForSale Queue

Example:
```
{
	"id" : "01-QUE"
}

```

POST --> ```/queue/delete```
NOT YET IMPLEMENTED

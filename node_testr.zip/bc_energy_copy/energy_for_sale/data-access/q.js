class Que {
  constructor(options) {
    this.queue = options.name || 'query'
    this.url = process.env.MONGO_URL || 'mongodb://admin:change01@172.21.0.4:27017/EnergyApp?authSource=admin'
    this.mongodb = require('mongodb').MongoClient
    this.mongoDBQueue = require('mongodb-queue')
    this.db = null;
  }

  close(){
    this.db.close()
  }

  connect(url, cb) {
    this.mongodb.connect(url, (err, db) => {
      this.db = db
      cb(err, db)
    })
  }
  /**
   * This is getQueue method. Usage: Returns specific Queue, queried by mongo ObjectID. 
   * ObjectID is returned to client upon creation of Queue
  */
  getQueue(id, cb) {
    this.connect(this.url, (err,db) => {
    if (err) {
      console.log(err)
        cb(err)
        db.close()
          } else {
              db.collection(id).find().toArray().then(
                (docs) => cb(docs),
                (err) => cb(err, null))
        db.close()
            }
    })
  }

  /**
  * This is createQueue method. Usage: Create EnergyForSale Listing Que. 
  * @param {string} doc - The Que to be added
 */

  createQueue(doc, cb) {
    this.connect(this.url, (err, db) => {
      if (err) {
        console.log(err)
          db.close()
          cb(err)

      } else {
        let queue = this.mongoDBQueue(db, this.queue);
        queue.add(doc, function (err, id) {
          if (err) {
            console.log(err)
            cb(null, err)
          } else {
            cb(id, null)
          }
            db.close()
        })
      }
    })
  }

  addToQue(doc, cb) {
    this.connect(this.url, (err,db) => {
    if (err) {
      console.log(err)
        db.close()
        cb(err)
          } else {
        console.log('adding Queue for dequeue '+this.queue)
            let queue = this.mongoDBQueue(db, this.queue);
            queue.add(doc, (err, id) =>{
              if(err){
                console.log(err)
                cb(err)
              }else {
                  console.log('enqueue successfull :' + id)
                  cb(id)
              }
                db.close()
            })

              //
              //   db.collection(id).insertOne(doc, (err, doc) => {
              //       if(err){
              //           console.log(err)
              //           db.close()
              //       }else {
              //       cb(doc.ops)
              //       db.close()
              //   }
              // })
            }

    })
  }

  dequeue(doc, cb) {
    console.log('Starting dequeue')
    this.connect(this.url, (err,db) =>{
      if(err){
        console.log(err)
          db.close()
          cb(err)
      }else{
          console.log('getting Queue for dequeue '+this.queue)
        let queue = this.mongoDBQueue(db, this.queue)
          queue.get((err, doc) =>{
            if (err || typeof doc === 'undefined'){
                cb(err)
                return
            }else if(typeof doc === 'undefined'){
              cb('doc undefined')
                return
            }

            let item = doc;
            console.log("Got item "+item)
              queue.ack(doc.ack, (err, id) =>{
                console.log("remove item "+id)
                  console.log(item)
              })

              cb(item)
              db.close()
          })
      }
    })
  }
//TODO buggy
  isEmpty(cb){
    this.connect(this.url, (err,db) =>{
      if(err){
        console.log(err)
          db.close()
          cb(err)
      }else{
        let queue = this.mongoDBQueue(db, this.queue)
          queue.size((err,count)=>{
            if(err){
              console.log(err)
                cb(err)
            }
            console.log('This queue has %d current messages', count)
              if(count <= 0){
                cb(true)
              }else{
                cb(false)
              }
          })
          db.close()
      }
    })
  }

  //TODO return message buggy
  wipeClean(cb){
    this.connect(this.url, (err, db)=>{
      if(err){
        console.log(err)
          cb(err)
      }else {
          db.collection(this.queue).drop(function (err, delOK) {
            if(err){
                console.log('deleted throws err')
              cb(err)
            }else if(delOK){
              console.log('deleted collection')
                cb(delOK)
            }
          })
          db.close()
      }
    })
  }

}




module.exports = Que

const { MongoClient , ObjectID} = require('mongodb')

class MongoDataAccess {

    constructor(connectionURL){
        this.connectionURL = connectionURL
        this.db = null
        MongoClient.connect(this.connectionURL, (err, database) => {
            if(err) 
                throw err
            else {
                this.db = database
            }
        })
    }

    addMultipleItems (collectionName, docs) {
        return this.db.collection(collectionName).insertMany(docs)
    }
    
    addItem(collectionName, item) {
       return this.db.collection(collectionName).insertOne(item)
    }
       
    findAll(collectionName) {
        return this.db.collection(collectionName).find().toArray() 
    }
    
    findbyId(collectionName, itemID) {
        return this.db.collection(collectionName).find({_id: new ObjectID(itemID)}).toArray()                       
    }

    deleteById(collectionName, id){
        return this.db.collection(collectionName).findOneAndDelete({_id: new ObjectID(id)})
    } 

    deleteAll(collectionName) { 
        return this.db.collection(collectionName).deleteMany()           
    }

    update(collectionName, id, updateItem){

       console.log('in update', updateItem)
       return this.db.collection(collectionName).findOneAndUpdate({_id: new ObjectID(id)},
        {
          $set: {
            ...updateItem
          }
        },
        {
          returnOriginal:false
        })
    }
}

module.exports = MongoDataAccess


#!/usr/bin/env bash

COMPOSEFILE=./env/composer-files/node-mongo.yml

export MONGODATA=${MONGODATA:-"${HOME}/mongodb/data"}
export MONGO_PORT=${MONGO_PORT:-3050}


function up(){
    echo "Bringing up with Mongo data at : ${MONGODATA}"
    docker-compose -f ${COMPOSEFILE} build
    docker-compose -f ${COMPOSEFILE} up -d
}
function down(){
    echo "Bringing down"
    docker-compose -f ${COMPOSEFILE} down
}

function restart(){
    echo "Restarting"
    down
    up
}


for opt in "$@"
do
    case "$opt" in
        up)
            up
            ;;
        down)
            down
            ;;
        restart)
            restart
            ;;
        *)
            echo $"Usage: up | down | restart"
            exit 1
esac
done

exit 0
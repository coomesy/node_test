#### GET Users #### 
##### https://guarded-shelf-72189.herokuapp.com/users #####

   Returns all users 

#### GET Transactions ####
##### https://guarded-shelf-72189.herokuapp.com/transactions #####

  Rerturns all transactions 

#### GET EnergyForSale #### 
##### https://guarded-shelf-72189.herokuapp.com/list #####

Returns all EnergyForSale items 



#### Create Transaction #### 
##### POST/ https://guarded-shelf-72189.herokuapp.com/transactions #####

Adds a new item to transaction collection
###### Example ######

 ``` javascript 
 {
    "energyRate": "11",
    "energyValue": "55",
    "coinsInc": "33",
    "coinsDec": "11",
    "energyInc": "22",
    "energyDec": "10",
    "transactionId": "005324231", 
    "timestamp": "3-3-18",
    "status": "failed"
}
``` 
 
#### Create User #### 
##### POST/ https://guarded-shelf-72189.herokuapp.com/users #####
Adds a new item to users collection

###### Example ######

 ``` javascript 
{
    "res_id": "444",
    "username": "Ashki_Jabib",
    "password": "jabs",
    "energyID":"111",
    "cashID": "9",
    "coinID": "00",
    "address": "333 cental avenue " ,
    "state": "empty" ,
    "transactions": [] ,
    "alias": "the great jabs ",
    "resident_type": "prosumer",
    "kWhUsed": "10"
  }
```

#### Create Transaction #### 

##### POST/ https://guarded-shelf-72189.herokuapp.com/list #####
Adds a new item to energy collection

###### Example ######

 ``` javascript 
  {
    "energyRate": "75",
    "energyValue": "60",
    "coinsInc": "5",
    "coinsDec": "5",
    "energyInc": "20",
    "energyDec": "10",
    "transactionId": "005324231",
    "timestamp": "3-3-18",
    "status": "failed"
}
``` 

